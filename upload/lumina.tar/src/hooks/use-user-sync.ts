'use client'

import { useEffect } from 'react'
import { useUser } from '@/lib/store'

/** Syncs the local user from the backend (creates one if needed) and updates the store. */
export function useUserSync() {
  const { userId, setHydrated } = useUser()

  useEffect(() => {
    let cancelled = false
    async function sync() {
      try {
        const res = await fetch('/api/user', { cache: 'no-store' })
        if (!res.ok) return
        const data = await res.json()
        const u = data.user
        if (u && !cancelled) {
          useUser.setState({
            userId: u.id,
            name: u.name,
            xp: u.xp,
            level: u.computedLevel || u.level,
            streak: u.streak,
          })
        }
      } catch {
        // ignore
      } finally {
        if (!cancelled) setHydrated(true)
      }
    }
    // Only fetch if we don't have a userId yet OR periodically
    if (!userId) sync()
    else setHydrated(true)

    return () => {
      cancelled = true
    }
  }, [])

  /** Manual refresh function. */
  return () => fetch('/api/user', { cache: 'no-store' }).then((r) => r.json())
}
