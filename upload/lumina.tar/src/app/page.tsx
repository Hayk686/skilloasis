'use client'

import { useEffect, lazy, Suspense } from 'react'
import { AppShell } from '@/components/app-shell'
import { useNav, useUser } from '@/lib/store'
import { useUserSync } from '@/hooks/use-user-sync'
import { HomeView } from '@/components/views/home-view'
import { SubjectsView } from '@/components/views/subjects-view'
import { PathsView } from '@/components/views/paths-view'
import { AchievementsView } from '@/components/views/achievements-view'
import { LoadingState } from '@/components/ui-blocks'

const DashboardView = lazy(() =>
  import('@/components/views/dashboard-view').then((m) => ({ default: m.DashboardView }))
)
const TutorView = lazy(() =>
  import('@/components/views/tutor-view').then((m) => ({ default: m.TutorView }))
)
const LessonsView = lazy(() =>
  import('@/components/views/lessons-view').then((m) => ({ default: m.LessonsView }))
)
const QuizView = lazy(() =>
  import('@/components/views/quiz-view').then((m) => ({ default: m.QuizView }))
)
const FlashcardsView = lazy(() =>
  import('@/components/views/flashcards-view').then((m) => ({ default: m.FlashcardsView }))
)
const MindMapView = lazy(() =>
  import('@/components/views/mindmap-view').then((m) => ({ default: m.MindMapView }))
)
const PlaygroundView = lazy(() =>
  import('@/components/views/playground-view').then((m) => ({ default: m.PlaygroundView }))
)

function ViewFallback({ label }: { label: string }) {
  return <LoadingState label={label} />
}

export default function Home() {
  const { view } = useNav()
  const { hydrated } = useUser()
  useUserSync()

  // Scroll to top on view change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }, [view])

  return (
    <AppShell>
      {!hydrated ? (
        <ViewFallback label="Загружаем твой профиль..." />
      ) : (
        <>
          {view === 'home' && <HomeView />}
          {view === 'dashboard' && (
            <Suspense fallback={<ViewFallback label="Открываем дашборд..." />}>
              <DashboardView />
            </Suspense>
          )}
          {view === 'tutor' && (
            <Suspense fallback={<ViewFallback label="Подключаем наставника..." />}>
              <TutorView />
            </Suspense>
          )}
          {view === 'lessons' && (
            <Suspense fallback={<ViewFallback label="Готовим урок..." />}>
              <LessonsView />
            </Suspense>
          )}
          {view === 'quiz' && (
            <Suspense fallback={<ViewFallback label="Готовим квиз..." />}>
              <QuizView />
            </Suspense>
          )}
          {view === 'flashcards' && (
            <Suspense fallback={<ViewFallback label="Готовим флешкарты..." />}>
              <FlashcardsView />
            </Suspense>
          )}
          {view === 'paths' && <PathsView />}
          {view === 'subjects' && <SubjectsView />}
          {view === 'achievements' && <AchievementsView />}
          {view === 'mindmap' && (
            <Suspense fallback={<ViewFallback label="Строим карту знаний..." />}>
              <MindMapView />
            </Suspense>
          )}
          {view === 'playground' && (
            <Suspense fallback={<ViewFallback label="Открываем песочницу..." />}>
              <PlaygroundView />
            </Suspense>
          )}
        </>
      )}
    </AppShell>
  )
}
